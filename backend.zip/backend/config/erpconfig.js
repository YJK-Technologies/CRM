module.exports = {

    user: "sample",
    password: "12345678",
    server: "localhost",
    database: "YJKERP",
    port: 1433,
    options: {
      encrypt: false,
    },
  };
  