// config/dbConfig.js
module.exports = {

  /*user: "sample",
  password: "12345678",
  server: "localhost",
  database: "sample",
  port: 1433,*/
  user: "saraswathi",
  password: "@%dSCt15",
  server: "95.216.47.253",
  database: "YJK_CRM",
  port: 1433,
  options: {
    encrypt: false,
  },   
  // user: "sample",
  // password: "123456789",
  // server: "192.168.29.229",
  // database: "YJKERP",
  // port: 1433,
  // options: {
  //   encrypt: false,
  // },   
};
