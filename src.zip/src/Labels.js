const labels = {
    createdBy: "Created By",
    createdDate: "Created Date",
    modifiedBy: "Modified By",
    modifiedDate: "Modified Date"
  };
  
  export default labels;