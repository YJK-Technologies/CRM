
import React from "react";
import ThemeSwitcher from './ThemeSwitcher';


const AppContent = () => {
    return (
    
        <ThemeSwitcher />
      
    );
  };



  export default AppContent;