const config = {
    apiBaseUrl: 'https://erpdev.yjktechnologies.com:5577' 
    // apiBaseUrl: 'http://95.216.47.253:5577'
  };
  
  module.exports = config;
