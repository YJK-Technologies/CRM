import React from 'react';
import './Loading.css';

const MyComponent = () => {
  return (
    <div class="loader-container">
    <div class="loader"></div>
    <div class="Text">Please Wait...</div>
  </div>
  
  );
};

export default MyComponent;
